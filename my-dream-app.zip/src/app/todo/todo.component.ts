import { Component, OnInit } from '@angular/core';
import { element } from 'protractor';
import {TodoService} from './shared/todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css'],
  providers:[TodoService]
})
export class TodoComponent implements OnInit {
  toDoListArray: any[];

  constructor(private todoServices: TodoService) { }

  ngOnInit() { 
    this.todoServices.getTodolist().snapshotChanges()
    .subscribe(item =>{
      this.toDoListArray=[];
      item.forEach(element =>{
        var x = element.payload.toJSON();
        x["$key"]= element.key;
        this.toDoListArray.push(x);
      })

      this.toDoListArray.sort((a,b)=>{
        return a.isChecked - b.isChecked; 
      })
    });
  }

  onAdd(itemTitle){
    this.todoServices.addtitle(itemTitle.value);
    itemTitle.value=null;

  }
  alterCheck($key : string , isChecked){
    this.todoServices.checkOrUncheckTitle($key, !isChecked);
  }
  onDelete($key:string){
    this.todoServices.removeTitle($key)
  }

}
