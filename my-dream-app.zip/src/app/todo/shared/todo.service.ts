import { ThrowStmt } from '@angular/compiler';
import { Injectable } from '@angular/core';
import {AngularFireDatabase , AngularFireList  } from '@angular/fire/database'

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  todoList : AngularFireList<any>;

  constructor(private firebasedb : AngularFireDatabase) { }

  getTodolist(){
    this.todoList= this.firebasedb.list('titles')
    return this.todoList;
  }

  addtitle(title : string){
    this.todoList.push({
      title:title, 
      isChecked:false
    });
  }
  checkOrUncheckTitle($key:string , flag:boolean){
    this.todoList.update($key ,{isChecked:flag});

  }

  removeTitle($key:string){
    this.todoList.remove($key);

  }



}

